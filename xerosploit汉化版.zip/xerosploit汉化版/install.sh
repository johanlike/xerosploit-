#!bin/bash
bash xerosploit汉化和BUG修复脚本.sh
rm  -rf "/opt/xerosploit/xerosploit.py"
cp "xerosploit.py"  "/opt/xerosploit/xerosploit.py"
read -p "接下来是填写你的IP到index.hmtl里面，确认完毕按任意键继续"
service apache2 start
cp "/var/www/html/index.html" "/var/www/html/index.html.bak" #备份
rm -rf "/var/www/html/index.html"
cp "index.html"  "/var/www/html/index.html"
read -p "请将你生成的exploit.swf放到本目录中，确认完毕按任意键继续"
rm -rf "/var/www/html/exploit.swf"
cp "exploit.swf" "/var/www/html/exploit.swf"
echo "现在请在终端开始运行xerosploit"
read -p "确认按任意键退出"
echo "我是打酱油的，有问题别问我啊"
exit
