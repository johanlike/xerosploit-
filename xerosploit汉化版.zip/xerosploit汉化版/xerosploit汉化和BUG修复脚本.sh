#!bin/bash
echo 骚年！准备好开始安装了吗？
echo "按CTRL+C取消安装，如果安装遇到报错，请检查是否连接VPN或代理"
read -p "要完整安装此工具必须连接SSR或VPN进行（换源也是可以的就是看你找不找的到），确认连接成功请按任意键继续安装"
git clone https://github.com/LionSec/xerosploit
cd xerosploit && sudo python install.py
echo "骚年！已经安装完成，接下来开始汉化并修复此工具的BUG。"
read -p "请确认当前目录下有已经汉化的xerosploit.py，确认完毕按任意键继续"
mkdir /home/home
touch /home/home/xero-html.html
cp   "/opt/xerosploit/xerosploit.py"  "/opt/xerosploit/xerosploit.py.bak1" #备份
rm -rf "/opt/xerosploit/xerosploit.py"
echo "骚年！已经汉化和修复此工具BUG，请开始享用！"
read -p "确认完毕按任意键退出"
echo  "( ^_^)／ 关闭中 ... 再见骚年.欢迎加入我们的kali linux 交流群：540675784"
exit
